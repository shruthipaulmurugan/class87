const firebaseConfig = {
  apiKey: "AIzaSyCFQpxZTtJ1SaIpCB-9QCgwKWOear4x884",
  authDomain: "storytelling-app-6f7fa.firebaseapp.com",
  projectId: "storytelling-app-6f7fa",
  storageBucket: "storytelling-app-6f7fa.appspot.com",
  messagingSenderId: "891201635356",
  appId: "1:891201635356:web:f8c98a8f80b0bc4b914bd9",
  measurementId: "G-7ECLDXL71V"
};